./Z80asm.exe -nh main.asm
